By default, the tar program doesn't compress its contents, which can be wasteful
of space. However, tar does support compression. Once again:

$ man tar

will tell you how to use the tar command to invoke the gnu zip
decompression function on a tarball.

In Unix, file suffixes are purely optional, but usually try to be
informative. So a file name ending in .tar is a hint to people to use
tar to unpack it. Similarly, ending it in .tgz suggests that it's a
gzipped tar file.
